<?php

session_name('tzLogin');
session_set_cookie_params(2*7*24*60*60);
session_start();
?>

<!DOCTYPE html>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registered users only!</title>
    
    <link rel="stylesheet" type="text/css" href="secret.css" media="screen" />
    
</head>

<body>

<div id="main">
  <div class="container">
    <h1>Present for Rookies of the secret!</h1>
    <h2></h2>
    </div>
    
    <div class="container">
    
    <?php
	if($_SESSION['id'])
	echo '<iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" name="Rick Rolled" height="468.75px" width="750px" allowfullscreen></iframe>';
	else echo '<h1>Please, <a href="secret.php">login</a> and come back later!</h1>';
    ?>
    </div>
    
  <div class="container tutorial-info">
 The master mind behind this project - www.daniels-rotbarts.com   </div>
</div>


</body>
</html>
