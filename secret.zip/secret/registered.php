<?php

session_name('tzLogin');
session_set_cookie_params(2*7*24*60*60);
session_start();
?>

<!DOCTYPE html>
<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registered users only!</title>
    
    <link rel="stylesheet" type="text/css" href="secret.css" media="screen" />
    
</head>

<body>

<div id="main">
  <div class="container">
    <h1>Registered Users Only!</h1>
    </div>
    
    <div class="container">
    
    <?php
	if($_SESSION['id'])
	echo '<h1>Greetings, '.$_SESSION['usr'].'! You have logged in!</h1><img src="login_panel/images/42.jpg" alt="42" width="750" height="468.75"><a href="registered1.php" style="margin-left:45%;font-size:28px;font-weight:900;background-color:#2E8B7E;border:1px solid rgba(0,0,0,0.8);padding:5px;">Open</a>';
	else echo '<h1>Please, <a href="secret.php">login</a> and come back later!</h1>';
    ?>
    </div>
    
  <div class="container tutorial-info">
 The master mind behind this project - www.daniels-rotbarts.com   </div>
</div>


</body>
</html>
